#ifndef SEARCHABLE_ARRAY_BAG_HPP
# define SEARCHABLE_ARRAY_BAG_HPP

#include "./searchable_bag.hpp"
#include "./array_bag.hpp"

class array_bag;
class searchable_bag;

class searchable_array_bag: public array_bag, public searchable_bag
{
	public:
		searchable_array_bag();
		searchable_array_bag(const searchable_array_bag& b);
		searchable_array_bag& operator=(const searchable_array_bag& b);
		virtual ~searchable_array_bag();

		bool has(int) const;
};

#endif